# 🚀 Vercel Setup Guide for Fredy.AI

## Complete Step-by-Step Instructions

---

## Step 1: Prepare Your Code for GitHub

First, you need to upload the code to GitHub so Vercel can access it.

### Option A: Using GitHub Desktop (Easiest)

1. **Download GitHub Desktop**: https://desktop.github.com/
2. **Sign in** with your GitHub account
3. **Create New Repository**:
   - Click `File` → `New Repository`
   - Name: `fredy-ai`
   - Description: `Australia's AI Career Platform`
   - Choose local path where you'll put the code
   - Click `Create Repository`

4. **Add the files**:
   - Copy all files from the `fredy-ai-nextjs` folder I created into your repository folder
   - GitHub Desktop will show all the new files
   - Write commit message: `Initial commit`
   - Click `Commit to main`
   - Click `Publish repository`
   - Uncheck "Keep this code private" if you want it public (or keep checked for private)
   - Click `Publish Repository`

### Option B: Using Command Line

```bash
# Navigate to the folder with your code
cd fredy-ai-nextjs

# Initialize git
git init

# Add all files
git add .

# Commit
git commit -m "Initial commit"

# Create repo on GitHub first at github.com/new, then:
git remote add origin https://github.com/YOUR_USERNAME/fredy-ai.git
git branch -M main
git push -u origin main
```

---

## Step 2: Connect Vercel to GitHub

### 2.1 Log into Vercel

1. Go to **https://vercel.com**
2. Click **"Log In"** (top right)
3. Choose **"Continue with GitHub"**
4. Authorize Vercel to access your GitHub account

### 2.2 You'll see the Vercel Dashboard

The dashboard shows:
- Overview (your projects)
- Integrations
- Settings
- Usage

---

## Step 3: Import Your Project

### 3.1 Click "Add New..." → "Project"

You'll see this at the top right of the dashboard.

### 3.2 Import Git Repository

1. You'll see a list of your GitHub repositories
2. Find **`fredy-ai`** in the list
3. Click **"Import"** next to it

> **Can't see your repo?** Click "Adjust GitHub App Permissions" and grant access to the repository.

### 3.3 Configure Project

You'll see a configuration screen:

**Project Name**: `fredy-ai` (or whatever you want)

**Framework Preset**: Should auto-detect as `Next.js` ✓

**Root Directory**: Leave as `./` (unless your code is in a subfolder)

**Build and Output Settings**: 
- Leave all defaults (Vercel knows how to build Next.js)

**Environment Variables** (optional for now):
- You can add these later
- For now, just deploy without any

### 3.4 Click "Deploy"

Vercel will now:
1. Clone your repository
2. Install dependencies (`npm install`)
3. Build the project (`npm run build`)
4. Deploy to their servers

**This takes about 1-2 minutes.**

---

## Step 4: Your Site is Live! 🎉

Once deployment completes, you'll see:

```
✓ Production Deployment

https://fredy-ai.vercel.app
```

Click the URL to see your live site!

---

## Step 5: Add Custom Domain (Optional)

### 5.1 Go to Project Settings

1. Click on your project `fredy-ai`
2. Click **"Settings"** tab
3. Click **"Domains"** in the sidebar

### 5.2 Add Your Domain

1. Type your domain: `fredy.ai` or `fredy.com.au`
2. Click **"Add"**

### 5.3 Configure DNS

Vercel will show you DNS records to add. Go to your domain registrar:

**For Apex Domain (fredy.ai):**
```
Type: A
Name: @
Value: 76.76.21.21
```

**For www subdomain:**
```
Type: CNAME
Name: www
Value: cname.vercel-dns.com
```

### 5.4 Wait for DNS Propagation

- Usually takes 5 minutes to 24 hours
- Vercel will automatically provision SSL certificate
- You'll see ✓ next to your domain when it's working

---

## Step 6: Environment Variables (When Needed)

### 6.1 Go to Project Settings → Environment Variables

Click **"Add New"** for each variable:

| Name | Value | Environment |
|------|-------|-------------|
| `NEXT_PUBLIC_SITE_URL` | `https://fredy.ai` | Production |

### 6.2 Redeploy

After adding environment variables:
1. Go to **"Deployments"** tab
2. Click the **"..."** menu on the latest deployment
3. Click **"Redeploy"**

---

## Step 7: Automatic Deployments

**Every time you push to GitHub, Vercel automatically deploys!**

### How it works:
1. You make changes to code locally
2. Commit and push to GitHub
3. Vercel detects the push
4. Automatically builds and deploys
5. New version live in ~1-2 minutes

### Preview Deployments:
- Push to a branch other than `main`
- Vercel creates a preview URL
- Test changes before going live
- Merge to `main` when ready

---

## Vercel Dashboard Overview

### Your Project Page Shows:

**Production**
- Current live deployment
- URL: fredy-ai.vercel.app
- Status: Ready ✓

**Deployments**
- History of all deployments
- Build logs
- Can rollback to any previous version

**Analytics** (Pro plan)
- Page views
- Web vitals
- Visitor data

**Settings**
- Domain configuration
- Environment variables
- Build settings
- Team members

---

## Troubleshooting

### Build Failed?

1. Click on the failed deployment
2. Click **"View Build Logs"**
3. Scroll to find the error
4. Common issues:
   - Missing dependencies → Check package.json
   - TypeScript errors → Fix type issues
   - Missing env variables → Add them

### Site Not Loading?

1. Check deployment status is "Ready"
2. Try hard refresh (Ctrl+Shift+R)
3. Check browser console for errors
4. Check Vercel function logs

### Domain Not Working?

1. Verify DNS records are correct
2. Check domain status in Vercel
3. Wait up to 24 hours for DNS propagation
4. Try `dig fredy.ai` to check DNS

---

## Quick Reference

| Action | How |
|--------|-----|
| Deploy | Push to GitHub `main` branch |
| Preview | Push to any other branch |
| Rollback | Deployments → ... → Promote to Production |
| Logs | Deployments → Click deployment → Logs |
| Env Vars | Settings → Environment Variables |
| Domain | Settings → Domains |
| Redeploy | Deployments → ... → Redeploy |

---

## Cost (Free Tier Includes)

✅ Unlimited deployments  
✅ 100GB bandwidth/month  
✅ Automatic HTTPS/SSL  
✅ Custom domains  
✅ Preview deployments  
✅ GitHub integration  

**Paid plans needed for:**
- Team collaboration
- Analytics
- More bandwidth
- Priority support

---

## Next Steps After Deployment

1. ✅ **Test the site** - Click through all pages
2. ✅ **Check mobile** - Responsive design
3. ✅ **Add domain** - When you have one
4. 📧 **Set up database** - Supabase (see separate guide)
5. 📧 **Set up email** - SendGrid (see separate guide)
6. 📊 **Add analytics** - Google Analytics

---

## Need Help?

- Vercel Docs: https://vercel.com/docs
- Vercel Support: https://vercel.com/support
- Next.js Docs: https://nextjs.org/docs

---

**You're ready to go live! 🚀**
